install_hpdiag Role
=========

This role will install HP Diagnostics for Linux into either EAP 6.x+ or Karaf Fuse

Requirements
------------

Before running this role you must have received from the monitoring team the HP Server you are expected to send data to.

Role Variables
--------------

The variables listed here must be added to group_vars/<group_name>.  Replace FS_APP_LOAD and CATL0SM138 with values appropriate for your environment

    HP_AGENT_GROUP: FS_APP_LOAD
    HP_SERVER: CATL0SM138

Next, depending on if you are installing to eap or fuse, set one of the following 2 variables to true.  They are both false by default

    update_jboss_env: true
    update_fuse_env: true


The variable listed here must be added to host_vars/<hostname>.  Replace FS_fsqv97_1 with a value appropriate for your host

    HP_AGENT_NAME: FS_fsqv97_1

\# These defaults should be ok for all env

    HP_SERVER_PORT: 2006
    HP_AGENT_BINARY: HPDiagTVJavaAgt_9.21.127.1572_linux.bin
    HP_PROFILER_PW: "{{ hp_profiler_pw }}"
    HP_UPLOAD_DIR: /opt/app/hpdiagnostics
    java_home: /opt/app/java/current
    fuse_env_file: /opt/app/fuse/current/bin/setenv

Example Commands
----------------

    ansible-playbook -i fs_hosts playbooks/install_hpdiag.yml -e target=fs_qa_app --ask-vault-pass

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
