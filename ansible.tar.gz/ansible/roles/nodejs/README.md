node.js Installation for Cox Communications
=========

This role will install node.js, oracle instantclient, and a opensource framework to start/stop the node.js application server.

Requirements
------------

Any pre-requisites that may not be covered by Ansible itself or the role should be mentioned here. For instance, if the role uses the EC2 module, it may be a good idea to mention in this section that the boto package is required.

Role Variables
--------------

The following listed below are the current default variables for node.js

	# defaults file for nodejs
	nodejs_base_mount: /opt/app
	nodejs_home: "{{ nodejs_base_mount }}/nodejs/node-v0.12.7-linux-x64"
	nodejs_upload_dir: "{{ nodejs_base_mount }}/software"
	nodejs_deploy_dir: "{{ nodejs_extract_dir }}/deploy"
	nodejs_log_dir: "{{ nodejs_base_mount }}/logs"
	nodejs_scripts_dir: "{{ nodejs_base_mount }}/scripts"
	nodejs_run_dir: "{{ nodejs_base_mount }}/run"
	nodejs_archive_name: node-v0.12.7-linux-x64
	nodejs_extract_dir: "{{ nodejs_base_mount }}/nodejs"
	nodejs_extract_name: node-v0.12.7-linux-x64
	nodejs_link: current
	nodejs_profile: "{{ nodejs_base_mount }}/.bash_profile"
	update_nodejs_link: false

	# application specific
	nodejs_application: set_value

	#oracle instantclient values
	orabasic_archive_name: instantclient-basic-linux.x64-11.2.0.4.0
	orasdk_archive_name: instantclient-sdk-linux.x64-11.2.0.4.0
	update_oraclient_link: false
	nodejs_oraclient: false
	oraclient_link: current
	oraclient_extract_dir: "{{ nodejs_base_mount }}/instantclient"
	oraclient_version: instantclient_11_2


Dependencies
------------

No dependencies exist at this time.

Example Playbook
----------------

	ansible-playbook -i (host file) playbooks/install_nodejs.yml -e target=group/host

License
-------

License: Cox Communications Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
