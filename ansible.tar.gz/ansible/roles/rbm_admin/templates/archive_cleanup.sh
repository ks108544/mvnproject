#!/bin/sh
#
#This script will delete and compress files in the /opt/shared/archive directory

#Delete all files older than 60 days
find /opt/shared/archive -name "*.gz" -mtime +60 -exec rm {} \;

#Compress files which are older than 30 days
find /opt/shared/archive -name "*.read" -mtime +30 -exec gzip -9 {} \;
find /opt/shared/archive -name "*.arc.[12345]" -mtime +30 -exec gzip -9 {} \;
