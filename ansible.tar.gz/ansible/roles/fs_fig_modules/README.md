fs_fig Role
=========

This role will pull a single file from buildlib over HTTP and place the file in the given directory.  Starting/Stopping JBOSS are options and are enabled by default.

Requirements
------------

The URL provided for buildlib is correct and accurate.

Role Variables
--------------

The variables listed here are best passed as arguments on the command line since this role is expected to be used for any service.

    war_url is the HTTP URL from the build complete / RPR.
    deploy_war must be set to "yes" if you want to actually deploy the war.

These defaults should be ok for current FIG environments, but could be changed in group_vars/<group_name>

    jboss_base_path: /opt/app/jboss/current

    fig_script_dir: /opt/app/scripts
    fig_temp_dir: /opt/app/fig_temp

    fig_check_script: check_jboss.ksh
    fig_start_script: start_jboss.ksh
    fig_stop_script:  stop_jboss.ksh

    stop_jboss: true
    start_jboss: true

Example Commands
----------------

Download apache-log4j-extras-1.0.jar and deploy to modules/com/cox/commons/loggingutil/main/:
    ansible-playbook -i fs_hosts playbooks/deploy_fig_modules.yml -e "target=fs_stg_ws item_url=http://buildlib/OBID/FSA-WFM2-LoggerUtil/3.8.33/dist/apache-log4j-extras-1.0.jar dest_path=modules/com/cox/commons/loggingutil/main/ "

Same as above, but include stop JBOSS, but do not restart it:
    ansible-playbook -i fs_hosts playbooks/deploy_fig_modules.yml -e "target=fs_stg_ws item_url=http://buildlib/OBID/FSA-WFM2-LoggerUtil/3.8.33/dist/apache-log4j-extras-1.0.jar dest_path=modules/com/cox/commons/loggingutil/main/ start_jboss=false stop_jboss=true"

Command Parameters
------------------

item_url=buildlib-path-to-deployment-artifact
dest_path=destination-folder (relative to the jboss_base_path)
stop_jboss=true/false
start_jboss=true/false

License
-------

Cox Communcations Proprietary

Author Information
------------------

Marty Sheffield
