wfm_web Role
=========

This role will pull from buildlib and deploy the web content.  It creates a backup of existing content into the defined web_archive_dir, removes all existing content, then downloads the new content.  It does not current perform any stop or start action on Apache.

Requirements
------------

This variable must be updated in group_vars to match desired code version (found in the rpr or build complete email)

\# Sample URL: http://BuildLib/OBID/NWFMPortal/1.15.3935

    wfm_web_ver: no_default, but would be 1.15.3935 from sample above

Role Variables
--------------

The variables listed here could be added to group_vars/<group_name> to over-ride any of these default values.  They should be ok for all environments

    wfm_web_dir: /opt/app/vantage
    wfm_web_archive_dir: /opt/app/archive
    wfm_web_buildlib: http://BuildLib/OBID/NWFMPortal

Example Commands
----------------

Download and deploy the web content

    ansible-playbook -i fs_hosts playbooks/deploy_wfm_web.yml -e target=fs_qa_iweb

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
