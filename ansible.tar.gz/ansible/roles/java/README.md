java Role
=========

The role will deploy the Java binaries to the destination server along with updating the cacerts file to include the Cox Certificate Authority

Requirements
------------

N/A

Role Variables
--------------

**java_source**: jdk-7u71-linux-x64 
**java_version**: jdk1.7.0_71  
**java_link**: "current"  
**java_base_dir**: "/opt/app/java"  
**java_upload_dir**: "/opt/app/software"  
**update_java_link**: false  

* Java_link - the name to use when making a link
* Java_base_dir - the base directory java will be installed to
* Java_upload_dir - The directory to copy the archive to on the destination server
* Java_source - the compressed archive file to deploy
* Java_version - The versioned directory name created when expanding the archive
* Update_java_link - determines if the script will make/replace the <java_link> in the <java_base_dir>.   Typically this is making a link with the value current that points to the fully versioned name.


Dependencies
------------

N/A

Example Playbook
----------------

`ansible-playbook playbooks/install_java.yml -e target=<target>`

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
