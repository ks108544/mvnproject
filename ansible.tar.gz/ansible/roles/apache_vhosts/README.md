apache_vhosts Role
=========

This role is designed to convert a single EWS (RedHat apache) instance into a multi-vhost instance.  For each apache_vhost section defined the role will create a virtual host in the conf.d directory.  The role also supports setting up reverse proxy mapping for 0 or more proxy instances.  Each Proxy section will rendor into the vhost config file.  Each vhost instance will have a dedicated set of log files.  Using the variables from the examples below, the resulting files will be:

    # Configuration files
    /opt/app/apache/jboss-ews-2.0/httpd/conf.d/ssl.conf
    /opt/app/apache/jboss-ews-2.0/httpd/conf.d/ssl_vantage.conf
    /opt/app/apache/jboss-ews-2.0/httpd/conf.d/ssl_validation.conf

    # Log files
    /opt/app/apache/jboss-ews-2.0/httpd/logs/vantage_access_log
    /opt/app/apache/jboss-ews-2.0/httpd/logs/vantage_error_log
    /opt/app/apache/jboss-ews-2.0/httpd/logs/vantage_request_log
    /opt/app/apache/jboss-ews-2.0/httpd/logs/validation_access_log
    /opt/app/apache/jboss-ews-2.0/httpd/logs/validation_error_log
    /opt/app/apache/jboss-ews-2.0/httpd/logs/validation_request_log

Requirements
------------

The target system(s) must have originally been built with the apache role as it assumes those variables are already defined.

\# Variables used from the apache role

    listen_ip: No_DEFAULT                         #host_vars/\<hostname\>
    apache_extract_dir: /opt/app/apache           #group_vars/\<group_name\>
    apache_extract_name: /opt/app/apache/current  #group_vars/\<group_name\>
    apache_ssl_dir: /opt/app/ssl                  #group_vars/\<group_name\>

Role Variables
--------------

The variables listed here must be added to group_vars/\<group_name\>.  There will be 1 section per vhost, values below are samples

    apache_vhosts:
      vantage:
        listen_port: 1443
        site_name: vantage.dev.cox.com
        ssl_key: vantage.np-san.2014
        doc_root: /opt/app/vantage
      validation:
        listen_port: 1444
        site_name: vantage.dev.cox.com
        ssl_key: vantage.np-san.2014
        doc_root: /opt/app/validation
        proxies:
          -
            alias: svcgtwy
            target: https://svcgtwy.dev.cox.com
          -
            alias: fig
            target: https://jbossws.dev.cox.com


Example Commands
----------------

    ansible-playbook -i fs_hosts playbooks/install_apache_vhosts.yml -e target=fs_sandbox

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
