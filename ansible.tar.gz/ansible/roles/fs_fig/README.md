fs_fig Role
=========

This role will pull from buildlib and deploy the war file from a given URL.  It does not current perform any stop or start action on EAP.

Requirements
------------

Jboss must be up and running if the deploy_war option is used

It is expected that only a single war file will be present in the \<war_url\>/dist folder.  If the deployment requires any property file, modules or other changes those would still need to be performed manually prior to deploying the war file.

Role Variables
--------------

The variables listed here are best passed as arguments on the command line since this role is expected to be used for any service.

    war_url is the HTTP URL from the build complete / RPR.
    deploy_war must be set to "yes" if you want to actually deploy the war.

These defaults should be ok for current FIG environments, but could be changed in group_vars/<group_name>

    deploy_path: /opt/app/jboss/current/standalone/deployments
    fig_script_dir: /opt/app/scripts
    fig_temp_dir: /opt/app/fig_temp
    fig_check_script: check_jboss.ksh

Example Commands
----------------

Download and leave the war file in the \<fig_temp_dir\> for manual deployment

    ansible-playbook -i fs_hosts playbooks/deploy_fig_war.yml -e "target=fs_qa_ws war_url=http://buildlib/OBID/FSA-AuthenticateWS/3.7.66"

Download and deploy the war file, removing it from \<fig_temp_dir\> upon completion

    ansible-playbook -i fs_hosts playbooks/deploy_fig_war.yml -e "target=fs_qa_ws war_url=http://buildlib/OBID/FSA-AuthenticateWS/3.7.66 deploy_war=yes"

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
