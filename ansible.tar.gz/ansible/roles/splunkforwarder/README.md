splunkforwarder Role
=========

This role is used to install the splunk universal forwarder to a linux host

Requirements
------------
The index specified must already exist and sufficient splunk license must be available.

Role Variables
--------------
#roles/splunkforwarder/defaults/main.yml

# This default must be over-ridden in host/group_vars
splunkforwarder_default_index: none

# This default must be added for 172.x hosts in host/group_vars
splunkforwarder_output_destination: "172.18.224.66:9997, 172.18.224.67:9997"

# Eventually dvtc hosts will have a value also

# These defaults should be correct for duke/dvtc 10.x hosts
splunkforwarder_source: splunkforwarder-6.2.1-245427-Linux-x86_64.tgz
splunkforwarder_version: splunkforwarder-6.2.1-245427-Linux-x86_64
splunkforwarder_base_dir: "/opt/app"
splunkforwarder_upload_dir: "/opt/app/software"
splunkforwarder_scripts_dir: "/opt/app/scripts"
splunkforwarder_output_destination: "dukesppi03:9997, dukesppi02:9997"


Dependencies
------------

N/A

Example Playbook
----------------
#ansible-playbook -i <hostfile_name> playbooks/install_splunkforwarder.yml -e target=xxxxx

- name: "Install Splunk Universal Forwarder"
  hosts: "{{ target }}"
  roles:
    - splunkforwarder

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
