Role Name
=========

This role will install precompiled Apache 2.4.x (currently 2.4.10) to the specified system/systems.

Requirements
------------

This role requires a few system libraries to install.  The role will perform the check and report back which libraries are missing.  

	ask your Linux admin to sudo yum -y install apr apr-util mailcap

Role Variables
--------------

This role supports one 'dictionary list' to add in Proxy configuration.

	#default variables below
	listen_port: 1443
	listen_ip: 127.0.0.1

	site_name: default.site.name

	apache_base_mount: /opt/app
	apache_doc_root:  "{{ apache_base_mount }}/htdocs"
	apache_user: apache
	apache_group: apache
	apache_link: current
	update_apache_link: false

	apache_archive_name: 2.4.10
	apache_extract_name: 2.4.10
	apache_upload_dir: "{{ apache_base_mount }}/software"
	apache_extract_dir:  "{{ apache_base_mount }}/apache"
	apache_scripts_dir:  "{{ apache_base_mount }}/scripts"
	apache_logrotate_dir:  "{{ apache_base_mount }}/logrotate"
	apache_log_dir:  "{{ apache_base_mount }}/logs"
	apache_ssl_dir:  "{{ apache_base_mount }}/ssl"
	apache_home: "{{ apache_extract_dir }}/{{apache_extract_name }}"

	apache_check_script: check_apache.ksh
	apache_start_script: start_apache.ksh
	apache_stop_script: stop_apache.ksh

	apache_ssl_protocol: "All -SSLv2 -SSLv3"
	apache_ssl_cipher_suite: "AES256+EECDH:AES256+EDH"
	apache_ssl_key: none

	apache_https: true
	apache_grep: httpd
	apache_process: httpd


Dependencies
------------

Make sure that the prerequisites have been met for this role before installation.

Playbook Execution
----------------

    ansible-playbook -i (host file) playbooks/install_coxapache.yml -e target=(target)

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
