jvm_stats Role
=========

This role will add a jvm stat collecting script and cron to collect jvm percent memory used for old space, the number and duration of full garbage collection cycles.  It can optionally update the Splunk inputs.conf to index the output file.

Requirements
------------

The role is currently only has an option for fuse.  Fuse refers to middleware RedHat karaf instance

Role Variables
--------------

These VARS apply just when install_type=fuse.  They can not be over-rode via host/group_vars.  You must pass any alternate values on the command line.

    jvm_log_name: fuse_perf.log
    jvm_grep_pattern: "java -server"
    jvm_script_name: fuse_stats.ksh

These defaults should be ok for most environments.  You can over-ride their values by placing entries into group/host_vars

    jvm_scripts_dir: /opt/app/scripts
    jvm_log_dir: /opt/app/logs
    jvm_jstat_path: /opt/app/java/current/bin/jstat

    jvm_update_splunk: false
    jvm_splunk_path: /opt/app/splunkforwarder
    jvm_splunk_inputs_file: "{{ jvm_splunk_path }}/etc/system/local/inputs.conf"

Example Commands
----------------

Install the script for fuse

    ansible-playbook -i bis_hosts playbooks/install_jvm_stats.yml -e "target=ew_qa_fun install_type=fuse"

Over-ride the VAR jvm_grep_pattern on the command line

    ansible-playbook -i bis_hosts playbooks/install_jvm_stats.yml -e "target=ew_qa_fun install_type=fuse jvm_grep_pattern='some pattern'"

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
