install_fuse Role
=========

The role will deploy the Fuse binaries to the destination server.

Requirements
------------

There are security roles, usernames and passwords that need to be set in either host_vars or group_vars.

**web_user**:  
**web_password**:  
**web_role**:  
**jmx_user**:  
**jmx_password**:  
**jmx_role**:  
**ssh_user**:  
**ssh_password**:  
**ssh_role**:  

Role Variables
--------------

**fuse_archive_name**: jboss-fuse-full-6.1.0.redhat-379.zip  
**fuse_extract_name**: jboss-fuse-6.1.0.redhat-379  
**fuse_upload_dir**: /opt/app/software  
**fuse_extract_dir**: /opt/app/fuse  
**fuse_scripts_dir**: /opt/app/scripts  
**fuse_ssl_dir**: /opt/app/ssl  
**fuse_home**: /opt/app/fuse/jboss-fuse-6.1.0.redhat-379  
**java_base_dir**: /opt/app/java  
**java_home**: /opt/app/java/current  
**fuse_link**: current  
**update_fuse_link**: false  

**init_heap_size**: 512  
**max_heap_size**: 512  
**init_perm_size**: 64  
**max_perm_size**: 256  

**ssh_port**: 8101    
**ssh_host**: 127.0.0.1  
**jaas_encryption_enabled**: "true"  
**hawtio_principal_classes**: org.apache.karaf.jaas.boot.principal.RolePrincipal  
**cxf_context**: ws  

**logging_max_file_size**: 100MB  
**logging_max_backups**: 10  
**logging_location**: /opt/app/logs/fuse.log  

**feature_boot**: jasypt-encryption,config,management,fabric,fabric-bundle,patch,mq-fabric,camel,war,hawtio  
**remote_maven_repo**: "https://repo.corp.cox.com/artifactory/cox-bis-virtual"  
**local_custom_repo**: ",file:/opt/app/fuse/custom-repo@id=karaf.custom-repo"  

Dependencies
------------

Java

Example Playbook
----------------

`ansible-playbook playbooks/install_fuse.yml -e target=<target>`

Tag Options --tags
----------------

dynamic_configs - No stop of fuse, just update the configs that are dynamic.  Currently that is the MVN URL.
update_configs  - Stops fuse if running, updates all config files
scripts         - No stop of fuse, redeploy the stop/start/check scripts only

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
