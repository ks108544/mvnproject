log_rotation ROLE
=========

This is a generic role you can call from a playbook to set up a logrotate based cron for the files / directories on your server.

Requirements
------------

Logrotate package installed on server

Role Variables
--------------

These should be ok for most current systems.  You might want to change the conf and status names under your group_vars/\<group_name\> if you are splitting out your rotates into more than 1 file.  

    logrotate_dir: /opt/app/logrotate
    logrotate_conf: logrotate_ansible.conf
    logrotate_status: logrotate_ansible.status

    logrotate_hour: "00"
    logrotate_minute: "35"

Dependencies
------------

N/A

Example Playbook
----------------

Example command to run a playbook using this role

    ansible-playbook -i fs_hosts playbooks/rotate_fig_logs.yml -e target=fs_qa_ws


The playbook itself needs a var section to define the log paths and rotation options

    - hosts: '{{ target }}'
      vars:
        logs:
          - 
            path: /opt/app/logs/boot.log
            options: 
              - daily
              - missingok
              - rotate 5
              - compress
              - copytruncate
              - notifempty
          - 
            path: /opt/app/logs/alert.log
            options: 
              - daily
              - missingok
              - rotate 5
              - compress
              - copytruncate
              - notifempty
          - 
            path: "/opt/app/jboss/current/standalone/log/*-[0-9][0-9]-[0-9][0-9].log"
            options: 
              - daily
              - missingok
              - rotate 1
              - compress
              - postrotate
              - "find /opt/app/jboss/current/standalone/log/*-[0-9][0-9]-[0-9][0-9].log.1.gz -mtime +5 -exec rm {} \\;"
              - endscript

      roles:
        - log_rotation


License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
