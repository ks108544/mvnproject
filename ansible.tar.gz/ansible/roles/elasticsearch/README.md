Elastic Search Role
=========

This role will install the elastic search application.  Based on the role you assign a server it can be a single node serving all functions or an individual function per node.  Functions include:  Master, Data or Client node.

Requirements
------------

The role expects that java has already been installed.  Work with the Linux admin on the host to enable limits.conf values for the account id you are running as.  Example values assuming user of esadmin

    /etc/security/limits.conf:
    esadmin - nofile 65535
    esadmin - memlock unlimited


Role Variables
--------------

    # Version Info
    es_archive_name: elasticsearch-1.7.2
    es_extract_name: elasticsearch-1.7.2
    es_version: 1.7

    # Directories
    es_base_mount: /opt/app
    es_upload_dir: "{{ es_base_mount }}/software"
    es_extract_dir: "{{ es_base_mount }}/elasticsearch"
    es_scripts_dir: "{{ es_base_mount }}/scripts"
    es_logs_dir: "{{ es_base_mount }}/logs"
    es_data_dir: "{{ es_base_mount }}/es_data"
    es_plugin_dir: "{{ es_base_mount }}/es_plugins"
    es_profile: "{{ es_base_mount }}/.bash_profile"

    # Scripts
    es_start_script: start_es.ksh
    es_start_grep: elastic
    es_stop_script: stop_es.ksh
    es_check_script: check_es.ksh

    # Links
    update_es_link: false                  # set to true in group_vars
    es_link: current

    # Plugins
    es_marvel_name: marvel-latest
    es_install_marvel: false               # If using this mgt plugin then set to true for all nodes

    # Configuration
    es_cluster_name: cluster_name          # set in group_vars
    es_node_name: "{{ ansible_hostname }}"
    es_node_master: "false"                # set to true in group_vars for master nodes only
    es_node_data: "false"                  # set to true in group_vars for data nodes only
    es_master_group: set_in_groupvars      # set to the ansible inventory group name of this clusters master nodes

    es_mlockall: "true"                    # Linux admin must allow in /etc/security/limits.conf
    es_network_host: 0.0.0.0               # set in host_vars as the service ip of the host
    es_cluster_port: 9300
    es_http_port: 9200
    es_http_enabled: "false"               # set to true in group_vars for client nodes only 

    es_zen_ping_timeout: 60s
    es_zen_multicast: false

    # JVM Options
    es_heap_size: 2g                       # set in group_vars.  Needs to be less than half the VM's ram allotment


Example Commands
----------------

Install entire application

    ansible-playbook -i retail_hosts playbooks/install_elasticsearch.yml -e target=es_poc

Install just the configuration files

    ansible-playbook -i retail_hosts playbooks/install_elasticsearch.yml -e target=es_poc --tags="configs"

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
