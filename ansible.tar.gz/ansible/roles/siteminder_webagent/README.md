Role Name
=========

This role will install the SiteMinder WebAgent to be used with Customer Facing websites here at Cox Communications.

Requirements
------------

Ensure that the sytems where this role is executed has the necessary firewall rules submitted.

Role Variables
--------------

Please review the default variables below and set accordingly in your applications group_vars, and or host_vars.

	# defaults file for siteminder_webagent
	sm_base_mount: /opt/app
	sm_upload_dir: "{{ sm_base_mount }}/software"
	sm_home: "{{ sm_base_mount }}/siteminder"
	sm_log_dir: "{{ sm_base_mount }}/logs"
	sm_archive_name: smwa-12.52-cr01-linux-x86-64
	sm_apache: false
	sm_install_rsp: smwa-12.52-cr01-linux-x86-64.rsp
	sm_config_rsp: ca-wa-config.rsp
	sm_apache_home: /opt/app/apache/current

	# host/group values provided by siteminder team
	sm_hco: modify_me
	sm_aco: modify_me
	sm_hostname: modify_me
	sm_policy_server: modify_me
	sm_policy_server_port: 44441
	sm_config: "{{ sm_home }}/webagent/config/SmHost.conf"

Dependencies
------------

This role has a dependency of Apache 2.4.x being installed to the host system. This role currently does not support JBoss EWS (Enterprise Web Server).  

Example Playbook
----------------

	ansible-playbook -i ptools_hosts playbooks/install_smwebagent.yml -e target=ptools_st1_web

License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)

