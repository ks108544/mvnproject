Automation Framework (auto.sh) Role
=========

This role installs the auto.sh framework along with SSH Key propagation between nodes. 

Requirements
------------

Prior to running the role, it is expected all applications have already been installed and have a start_<app>, stop_<app>, and check_<app> script in a central directory (/opt/app/scripts)

Role Variables
--------------

These defaults should be ok for most environments.  You can over-ride their values by placing entries into group/host_vars

    # Directories
    auto_base_mount: /opt/app
    auto_scripts_dir: "{{ auto_base_mount }}/scripts"

    # Dependent Variables
    auto_profile: .bash_profile
    update_auto_profile: true
    auto_instances:
      1: 'script.sh:somehost:process name:appid'

Example group_vars with more extensive auto_instances:

    # Automation Framework
    auto_instances:
      1: 'es.ksh:dukeivdv94:Master Node 1:zkpradm'
      2: 'es.ksh:dukeivdv95:Master Node 2:zkpradm'
      3: 'es.ksh:dukeivdv96:Master Node 3:zkpradm'
      4: 'es.ksh:dukeivdv98:Data Node 1:solradm'
      5: 'es.ksh:dukeivdv99:Data Node 2:solradm'
      6: 'es.ksh:dukeivdv97:Client Node 1:solradm'

Example Commands
----------------

Install the auto.sh script across all nodes in the group

     ansible-playbook -i retail_hosts playbooks/install_autosh.yml -e target=es_dev


License
-------

Cox Communcations Proprietary

Author Information
------------------

[Jet Team](mailto:jet@cox.com)
